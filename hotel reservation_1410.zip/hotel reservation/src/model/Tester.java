package model;

public class Tester {

    public static void main(String[] args) {

        Customer customer = new Customer("first", "last", "hans@maulwurf.com");
        System.out.println(customer);

        Customer customer2 = new Customer("Hans", "Person", "mail");
    }
}
