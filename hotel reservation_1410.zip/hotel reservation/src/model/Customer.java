package model;

import java.util.regex.Pattern;

public class Customer {

    private final String firstName;
    private final String lastName;
    private final String email;

    public Customer(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        if(isValidEmail(email)) {
            this.email = email;
        }
        else {
            System.out.println("Invalid email!");
            throw new IllegalArgumentException();
        }
    }

    public String getEmail() {
        return email;
    }

    public boolean isValidEmail(String email) {
        String emailRegex = "^(.+)@(.+).com$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    @Override
    public String toString() {
        return "--- First Name: " + firstName + " | Last Name: " + lastName + " | Email: " + email + " ---";
    }
}
