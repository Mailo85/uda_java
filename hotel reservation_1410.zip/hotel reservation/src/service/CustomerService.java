package service;

import model.Customer;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CustomerService {

    // Singleton
    private static CustomerService customerServiceSingleton = null;

    static Map<String, Customer> customers = new HashMap<String, Customer>();

    private CustomerService() {}

    public static CustomerService getInstance() {
        if(customerServiceSingleton == null) {
            customerServiceSingleton = new CustomerService();
        }
        return customerServiceSingleton;
    }

    public static void addCustomer(String email, String firstName, String lastName) {
        Customer customer = new Customer(firstName, lastName, email);
        customers.put(customer.getEmail(), customer);
    }

    public static Customer getCustomer(String customerEmail) {
        return customers.get(customerEmail);
    }

    public static Collection<Customer> getAllCustomers() {
        return customers.values();
    }
}
