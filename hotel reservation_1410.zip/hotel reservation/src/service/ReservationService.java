package service;

import model.Customer;
import model.IRoom;
import model.Reservation;

import java.util.*;

public class ReservationService {

    // Singleton
    private static ReservationService reservationServiceSingleton = null;

    static Collection<IRoom> rooms = new HashSet<>();
    static Collection<Reservation> reservations = new ArrayList<>();

    private ReservationService() {}

    public static ReservationService getInstance() {
        if(reservationServiceSingleton == null) {
            reservationServiceSingleton = new ReservationService();
        }
        return reservationServiceSingleton;
    }

    public static Collection<IRoom> getAllRooms() {
        return rooms;
    }

    public static void addRoom(IRoom room) {
        rooms.add(room);
    }

    public static IRoom getARoom(String roomId) {
        for(IRoom room : rooms) {
            if(room.getRoomNumber().equals(roomId)) {
                return room;
            }
        }
        System.out.println("There is no room with number " + roomId + " in the list!");
        return null;
    }

    public static Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }

    public static boolean isWithinRange(Date testDate, Date startDate, Date endDate) {
        return !(testDate.before(startDate) || testDate.after(endDate));
    }

    public static Date addDays(Date date, int days) {
        Date newDate = new Date(date.getTime());

        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(newDate);
        calendar.add(Calendar.DATE, days);
        newDate.setTime(calendar.getTime().getTime());

        return newDate;
    }

    public static Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        Collection<IRoom> availableRooms = getAllRooms();
        for(Reservation reservation : reservations) {
            if(isWithinRange(checkInDate, reservation.getCheckInDate(), reservation.getCheckOutDate()) || isWithinRange(checkOutDate, reservation.getCheckInDate(), reservation.getCheckOutDate())) {
                availableRooms.remove(reservation.getRoom());
                //System.out.println("Remove room " + reservation.getRoom().getRoomNumber());
            }
        }
        return availableRooms;
    }

    public static Collection<Reservation> getCustomersReservation(Customer customer) {
        Collection<Reservation> customersReservations = new HashSet<>();
        for(Reservation reservation : reservations) {
            if(reservation.getCustomer().equals(customer)) {
                customersReservations.add(reservation);
            }
        }
        return customersReservations;
    }

    public static void printAllReservations() {
        reservations.forEach(System.out::println);
    }
}
