import cli.MainMenu;

import java.text.ParseException;

public class HotelReservationApplication {

    public static void main(String[] args) throws ParseException {

        MainMenu mainMenu = new MainMenu();
        mainMenu.start();

        // We could also start with the Admin Menu:
        // AdminMenu adminMenu = new AdminMenu();
        // adminMenu.start();
    }
}