package cli;

import api.AdminResource;
import api.HotelResource;
import model.IRoom;
import model.Room;
import model.RoomType;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AdminMenu {

    public void showMenu() {
        System.out.println("---------------------------------------");
        System.out.println("1. View all customers");
        System.out.println("2. View all rooms");
        System.out.println("3. View all reservations");
        System.out.println("4. Add a room");
        System.out.println("5. Add test data");
        System.out.println("6. Back to Main Menu");
        System.out.println("---------------------------------------");
        System.out.println("Please select a menu option");
    }

    public int getMenuInput() {
        Scanner scanner = new Scanner(System.in);
        try {
            int input = scanner.nextInt();
            if(input > 0 && input <= 6) {
                return input;
            }
            else {
                System.out.println("Enter a valid option");
            }
        }
        catch (Exception ex) {
            System.out.println(ex.getLocalizedMessage());
        }
        return 0;
    }

    public void viewAllCustomers() {
        AdminResource.getAllCustomers().forEach(System.out::println);
    }

    public void viewAllRooms() {
        AdminResource.getAllRooms().forEach(System.out::println);
    }

    public void viewAllReservations() {
        AdminResource.displayAllReservations();
    }

    public void addRoom() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Room number:");
        String roomnumber = scanner.nextLine();
        System.out.println("Price:");
        Double price = scanner.nextDouble();
        System.out.println("Type (1 - Single | 2 - Double):");
        RoomType type = null;
        int input = scanner.nextInt();
        boolean roomtypeselected = false;
        while(!roomtypeselected) {
            if(input == 1){
                type = RoomType.SINGLE;
                roomtypeselected = true;
            }
            else if(input == 2) {
                type = RoomType.DOUBLE;
                roomtypeselected = true;
            }
            else {
                System.out.println("Please enter 1 for single room or 2 for double room!");
                input = scanner.nextInt();
            }
        }
        List<IRoom> roomsAdd = new ArrayList<>();
        roomsAdd.add(new Room(roomnumber, price, type));
        AdminResource.addRoom(roomsAdd);
        System.out.println("Room added!");
    }

    public void addTestData() throws ParseException {
        List<IRoom> testRooms = new ArrayList<>();
        testRooms.add(new Room("120", 125.0, RoomType.DOUBLE));
        testRooms.add(new Room("121", 136.0, RoomType.DOUBLE));
        testRooms.add(new Room("122", 125.0, RoomType.SINGLE));
        /*testRooms.add(new Room("201", 125.0, RoomType.SINGLE));
        testRooms.add(new Room("202", 145.0, RoomType.DOUBLE));
        testRooms.add(new Room("304", 125.0, RoomType.DOUBLE));
        testRooms.add(new Room("305", 155.0, RoomType.SINGLE));
        testRooms.add(new Room("310", 210.0, RoomType.DOUBLE));*/
        AdminResource.addRoom(testRooms);
        HotelResource.createACustomer("ed@mail.com", "Ed", "Oneill");
        HotelResource.createACustomer("fred@email.com", "Fred", "Manno");
        HotelResource.createACustomer("klaus@mail.com", "Klaus", "Peter");
        HotelResource.createACustomer("harry@hirsch.com", "Harry", "Hirsch");
        HotelResource.bookARoom("ed@mail.com", HotelResource.getRoom("120"), new SimpleDateFormat("MM/dd/yyyy").parse("12/05/2021"), new SimpleDateFormat("MM/dd/yyyy").parse("12/10/2021"));
        HotelResource.bookARoom("klaus@mail.com", HotelResource.getRoom("121"), new SimpleDateFormat("MM/dd/yyyy").parse("12/05/2021"), new SimpleDateFormat("MM/dd/yyyy").parse("12/10/2021"));
        HotelResource.bookARoom("harry@hirsch.com", HotelResource.getRoom("122"), new SimpleDateFormat("MM/dd/yyyy").parse("12/04/21"), new SimpleDateFormat("MM/dd/yyyy").parse("12/09/2021"));
        System.out.println("Test data added!");
    }

    public void startAction(int selection) throws ParseException {
        switch (selection) {
            case 1:
                viewAllCustomers();
                break;
            case 2:
                viewAllRooms();
                break;
            case 3:
                viewAllReservations();
                break;
            case 4:
                addRoom();
                break;
            case 5:
                addTestData();
                break;
            case 6:
                MainMenu mainMenu = new MainMenu();
                mainMenu.start();
                break;
        }
    }

    public void start() throws ParseException {
        while(true) {
            showMenu();
            int input = getMenuInput();
            startAction(input);
        }
    }
}
