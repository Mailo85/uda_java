package cli;

import api.AdminResource;
import api.HotelResource;
import model.IRoom;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {

    public void showMenu() {
        System.out.println("---------------------------------------");
        System.out.println("1. Find and Reserve a Room");
        System.out.println("2. My Reservations");
        System.out.println("3. Create Account");
        System.out.println("4. Admin");
        System.out.println("5. Exit");
        System.out.println("---------------------------------------");
        System.out.println("Please select a menu option");
    }

    public int getMenuInput() {
        Scanner scanner = new Scanner(System.in);
        try {
            int input = scanner.nextInt();
            if (input > 0 && input <= 5) {
                return input;
            } else {
                System.out.println("Enter a valid option!");
            }
        } catch (Exception ex) {
            System.out.println(ex.getLocalizedMessage());
        }
        return 0;
    }

    public void findAndReserveARoom() throws ParseException {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.println("Please enter checkin date (month/day/year):");
            Date checkInDate = new SimpleDateFormat("MM/dd/yyyy").parse(scanner.nextLine());
            System.out.println("Please enter checkout date (month/day/year):");
            Date checkOutDate = new SimpleDateFormat("MM/dd/yyyy").parse(scanner.nextLine());

            // Find available rooms for checkin and checkout dates

            System.out.println(AdminResource.getAllRooms());

            Collection<IRoom> availableRooms = HotelResource.findARoom(checkInDate, checkOutDate);
            // If there are no available rooms, search 7 days in the future.
            if (availableRooms.isEmpty()) {
                System.out.println("No available rooms for " + checkInDate + " - " + checkOutDate + "! Looking for rooms one week later...");
                checkInDate = HotelResource.addDays(checkInDate, 7);
                checkOutDate = HotelResource.addDays(checkOutDate, 7);

                System.out.println(AdminResource.getAllRooms());

                availableRooms = HotelResource.findARoom(checkInDate, checkOutDate);
                if (availableRooms.isEmpty()) {
                    System.out.println("No recommended rooms for " + checkInDate + " - " + checkOutDate + "!");
                    return;
                }
                availableRooms.forEach(System.out::println);
                System.out.println("Please enter the room you want to book:");
                String roomSelection = scanner.nextLine();
                IRoom room = HotelResource.getRoom(roomSelection);
                System.out.println("Please enter your email.");
                String email = scanner.nextLine();
                HotelResource.bookARoom(email, room, checkInDate, checkOutDate);
                System.out.println("Room was booked!");
            }
        } catch (ParseException ex) {
            System.out.println(ex.getLocalizedMessage());
        }
    }

    public void viewMyReservations() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your email:");
        String email = scanner.nextLine();
        HotelResource.getCustomersReservations(email).forEach(System.out::println);
    }

    public void createAccount() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please create an account:");
        System.out.println("Email:");
        String email = scanner.nextLine();
        System.out.println("First Name:");
        String firstName = scanner.nextLine();
        System.out.println("Last Name:");
        String lastName = scanner.nextLine();

        // Add account
        HotelResource.createACustomer(email, firstName, lastName);
        // Show created account
        System.out.println(HotelResource.getCustomer(email));
    }

    public void startAction(int selection) throws ParseException {
        switch (selection) {
            case 1:
                findAndReserveARoom();
                break;
            case 2:
                viewMyReservations();
                break;
            case 3:
                createAccount();
                break;
            case 4:
                AdminMenu adminMenu = new AdminMenu();
                adminMenu.start();
                break;
            case 5:
                System.exit(0);
        }
    }

    public void start() throws ParseException {
        while (true) {
            showMenu();
            int input = getMenuInput();
            startAction(input);
        }
    }
}
